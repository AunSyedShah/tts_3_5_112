import { StudentCard } from "./components/StudentCard";
import { AddStudent } from "./components/AddStudent";
import { useState } from "react";

export default function App() {
  const [students, setStudents] = useState([
    {
      "stud_name": "Mehwish",
      "stud_age": 21,
      "id": 1
    },
    {
      "stud_name": "Asaad",
      "stud_age": 25,
      "id": 2
    },
    {
      "stud_name": "Aqeel Chandio",
      "stud_age": 24,
      "id": 3
    },
    {
      "stud_name": "Zayan",
      "stud_age": 26,
      "id": 3
    }
  ])
  return (
    <div className="container mx-auto bg-slate-50">
      <AddStudent state={{ students, setStudents }} />
      <div className="flex flex-wrap justify-center">
        {
          students.map(
            function handler(student, index) {
              return (
                <StudentCard student={student} key={index} />
              )
            }
          )
        }
      </div>
    </div>
  )
}
