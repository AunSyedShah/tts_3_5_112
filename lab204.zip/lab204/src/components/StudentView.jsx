import { StudentCard } from "./StudentCard";

export default function StudentView({ students }) {
    return (
        students.map(
            function handler(student, index) {
                return (
                    <StudentCard student={student} key={index} />
                )
            }
        )
    )
}