export function StudentCard(props) {
    const { student } = props;
    const { state: { students, setStudents } } = props;

    function handleDelete(id) {
        alert("student deleted");
    }
    return (
        <div className="card w-80 sm:w-96 bg-base-100 shadow-xl m-4">
            <div className="card-body">
                <h2 className="card-title">{student.stud_name}</h2>
                <p>Age: {student.stud_age}</p>
                <div className="card-actions justify-end">
                    <button className="btn btn-error" onClick={function handle() { handleDelete(student.id) }}>Delete</button>
                    <button className="btn btn-warning">Update</button>
                </div>
            </div>
        </div>
    )
}