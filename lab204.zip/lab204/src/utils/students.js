export let students = [
    {
        "stud_name": 'syed',
        "stud_age": 25
    },
    {
        "stud_name": 'syeda',
        "stud_age": 25
    }
]