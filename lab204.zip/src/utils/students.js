export let students = [
    {
        "stud_id": "Student1",
        "stud_name": 'syed',
        "stud_age": 25
    }
]